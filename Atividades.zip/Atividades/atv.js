function somar() {
    let n1 = Number(window.prompt('Digite um número'))
    let n2 = Number(window.prompt('Digite outro número'))
    let n3 = Number(window.prompt('Digite mais um número'))

    let res = document.querySelector('section#res')
    res.innerHTML = `<span>O resultado de ${n1} mais ${n2} dividido por ${n3} é igual a ${(n1 + n2) / n3} </span > `
}

function dividir() {
    let n4 = Number(window.prompt('Qual a velocidade do carro?'))
    let n5 = Number(window.prompt('Qual a km que ele precisa percorrer?'))

    let res1 = document.querySelector('section#res1')
    res1.innerHTML = `<span>Será necessário ${n5 / n4} hora(s) para o carro percorrer ${n5} km.</span > `

}

function multiplicar() {
    let nome = window.prompt('Qual o seu nome?')
    let n7 = Number(window.prompt('Qual o seu salário?'))
    let n8 = Number(window.prompt('Qual foi o percentual do dissídio da sua Convenção Coletiva em 2023?'))
    var reajuste = (n7 * n8) / 100
    var salario = reajuste + n7

    let res2 = document.querySelector('section#res2')
    res2.innerHTML = `<span> Olá ${nome}, o seu salário com o reajuste será ${salario}.</span >`

}

function number() {
    let n11 = Number(window.prompt('Digite um número positivo, inteiro e diferente de zero'))

    let res4 = document.querySelector('section#res4')
    res4.innerHTML = `<span> ${n11} + 1 é igual a ${n11 + 1} e ${n11} - 1 é igual a ${n11 - 1}.</span >`

}

function aviao() {
    let n12 = Number(window.prompt('Qual a distância, em km, para o local que você quer chegar?'))

    let res5 = document.querySelector('section#res5')
    res5.innerHTML = `<span> Para chegar ao seu destino, a viagem de avião será de ${Math.round(n12 / 900)} hora(s).</span >`

}

function fazenda() {
    let n13 = Number(window.prompt('Quantos alqueires tem sua fazenda?'))
    let n14 = Number(window.prompt('Quantos caminhões você possui para transporte de laranjas?'))

    var alqueires = n13 * 250
    var caminhao = n14 * 18
    var viagens = alqueires / caminhao

    let res6 = document.querySelector('section#res6')
    res6.innerHTML = `<span>Será necessário fazer ${Math.round(viagens)} viagens para transportar toda a colheita de laranjas.</span >`

}

function cilindro() {
    let n15 = Number(window.prompt('Qual o raio deste cilindro em cm?'))
    let n16 = Number(window.prompt('Qual a altura deste cilindro em cm?'))

    var area = 2 * 3.14 * n15(n15 = n16)
    var volume = 3.14 * Math.pow(15, 3) * n16

    let res7 = document.querySelector('section#res7')
    res7.innerHTML = `<span>A área deste cilindro é igual a ${area} e o volume deste cilindro é igual a ${volume}.</span >`

}





