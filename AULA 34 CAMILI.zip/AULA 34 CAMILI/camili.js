document.getElementById('loginForm').addEventListener
    ('submit', function (event) {
        event.preventDefault();

        var username = document.getElementById('username').value;
        var password = document.getElementById('password').value;

        if (username === 'admin' && password === '1234') {
            document.getElementById('message').textContent =
                'Login efetuado com sucesso!';
            window.location = 'https://marquesfernandes.com/design/top-inspiracoes-de-design-para-pagina-de-login-e-cadastro/'
        } else {
            document.getElementById('message').textContent =
                'Usuário ou senha incorretos';
        }
    })